export const BubblyContainer = () => (
  <div id="react-bubbly-transitions__container" />
);
